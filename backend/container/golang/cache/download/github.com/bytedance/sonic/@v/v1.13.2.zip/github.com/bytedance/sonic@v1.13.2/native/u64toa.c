#include "fastint.h"


int u64toa(char *out, uint64_t val) {
    return u64toa_1(out, val);
}
